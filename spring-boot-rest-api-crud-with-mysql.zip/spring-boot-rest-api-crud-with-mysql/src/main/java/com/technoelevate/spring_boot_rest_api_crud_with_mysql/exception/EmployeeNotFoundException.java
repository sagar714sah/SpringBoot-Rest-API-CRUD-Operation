package com.technoelevate.spring_boot_rest_api_crud_with_mysql.exception;

public class EmployeeNotFoundException extends RuntimeException {
 
	   public EmployeeNotFoundException (String message) {
		   super(message);
	   }
}
