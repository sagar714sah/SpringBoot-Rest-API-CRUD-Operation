package com.technoelevate.spring_boot_rest_api_crud_with_mysql.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.technoelevate.spring_boot_rest_api_crud_with_mysql.entity.Employee;

import jakarta.transaction.Transactional;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	                             //here, we have made our UserDefindQuery methods
	
  Employee findByEmail(String email);
   
  @Query("select e from Employee e where e.name=?1")
  List<Employee> getEmployeeByName(String name);
  
  
  @Query("Delete from Employee e where e.name=?1")
  @Transactional
  @Modifying
  void deleteEmployeeByName(String name);
     
  }
