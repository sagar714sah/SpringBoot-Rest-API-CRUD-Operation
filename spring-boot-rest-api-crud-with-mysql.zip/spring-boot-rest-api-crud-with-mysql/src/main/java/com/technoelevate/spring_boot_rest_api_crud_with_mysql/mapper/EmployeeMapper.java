package com.technoelevate.spring_boot_rest_api_crud_with_mysql.mapper;

import com.technoelevate.spring_boot_rest_api_crud_with_mysql.Dto.EmployeeRequest;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.entity.Employee;

public class EmployeeMapper {
  
	/*
	 * @param employeeRequest
	 * 
	 * @return employee
	 */
	
	public static Employee convertToEmployee(EmployeeRequest employeeRequest) {
		Employee employee= new Employee();
		employee.setId(employeeRequest.getId());
		employee.setEmail(employeeRequest.getEmail());
		employee.setName(employeeRequest.getName());
		employee.setDepartment(employeeRequest.getDepartment());
		employee.setSalary(employeeRequest.getSalary());
		employee.setJoiningdate(employeeRequest.getJoiningdate());
		
		return employee;
	}
	
	public EmployeeRequest covertToEmployeeRequest(Employee employee) {
		EmployeeRequest employeeRequest= new EmployeeRequest();
		employeeRequest.setId(employee.getId());
		employeeRequest.setEmail(employee.getEmail());
		employeeRequest.setDepartment(employee.getDepartment());
		employeeRequest.setJoiningdate(employee.getJoiningdate());
		employeeRequest.setName(employee.getName());
		employeeRequest.setSalary(employee.getSalary());
		
		return employeeRequest;
	}
}
