package com.technoelevate.spring_boot_rest_api_crud_with_mysql.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Repository;

import com.technoelevate.spring_boot_rest_api_crud_with_mysql.SpringBootRestApiCrudWithMysqlApplication;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.Repository.EmployeeRepository;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.controller.EmployeeController;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.entity.Employee;

@Repository
public class EmployeeDao {



  

   
	
	@Autowired
	private EmployeeRepository repository;



   
	public Employee saveEmployeeDao(Employee employee) {
		
		return repository.saveAndFlush(employee);
	}
	
	public Employee getEmployeeByIdDao(int id) {
		              
		           Optional<Employee> optional = repository.findById(id);
		           
		           if(optional.isPresent()) {
		        	   return optional.get();
		           }
		           return null;
	}
	
	public List<Employee> getAllEmployeeDao(){
		return repository.findAll();
		
	}
	
	public List<Employee> saveMultipleEmployeeDao(List<Employee> employees){
		return repository.saveAll(employees);
	}
	
	public Employee getEmployeeByemailDao(String email){
		return repository.findByEmail(email);
		 
	}
	
	public List<Employee> getEmployeeByNameDao(String name){
		return repository.getEmployeeByName(name);
	}
	
	public boolean deleteEmployeeByNameDao(String name) {
		
		          List<Employee> employee =getEmployeeByNameDao(name);   // 1st check whether given name is present in the db or not
		          
		          if(employee.isEmpty()) {       //chgcking  part validation part
		        	  return false;
		          }
		  repository.deleteEmployeeByName(name);
		  return true;
	}
	
	public Page<Employee> getEmployeeWithPageNUmberDao(int pagenumber){
		return  repository.findAll(PageRequest.of(pagenumber,2 ));
		
		
	}
	
	public List<Employee> SortEmployeeBysalaryDao(String Salary){
		return repository.findAll(Sort.by(Order.desc(Salary)));
	}
	
	
	public List<Employee> sortEmployeeByAttributeNameDao(String attributeName){
		return repository.findAll(Sort.by(Order.asc(attributeName)));
				
	}
	
	public List<Employee> sortEmployeeByAttributeNameByDescDao(String attributeName){
		return repository.findAll(Sort.by(Order.desc(attributeName)));
	}

}
