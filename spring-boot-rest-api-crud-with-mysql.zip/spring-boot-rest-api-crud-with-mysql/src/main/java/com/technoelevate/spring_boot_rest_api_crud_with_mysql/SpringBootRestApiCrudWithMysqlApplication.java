package com.technoelevate.spring_boot_rest_api_crud_with_mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApiCrudWithMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiCrudWithMysqlApplication.class, args);
		System.out.println("application Started succesfully");
	}

}
