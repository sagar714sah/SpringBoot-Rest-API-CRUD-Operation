package com.technoelevate.spring_boot_rest_api_crud_with_mysql.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.spring_boot_rest_api_crud_with_mysql.Dao.EmployeeDao;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.Dto.EmployeeRequest;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.entity.Employee;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.exception.EmployeeNotFoundException;
import com.technoelevate.spring_boot_rest_api_crud_with_mysql.mapper.EmployeeMapper;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RequestMapping("/Employee")
@RestController

public class EmployeeController {

      
@GetMapping(value="/random")
	public static int getRandom() {
		return (int) (Math.random()*100);
		
	}
@GetMapping(value="/addition/{a}/{b}")
public double getAdditionOfTwoNumber(@PathVariable (name="a") int a,@PathVariable (name="b") int b) {
	return a+b;
	
}
 
@Autowired
private EmployeeDao employeedao;
                                             // NORMAL SAVE METHOD
//@PostMapping(value="/saveEmployee" , produces ="application/json")
//public Employee saveEmployeeControler(@RequestBody Employee employee) {
//  System.out.println("employeesaved"+employee);
//  
//	return employeedao.saveEmployeeDao(employee);    
//	
//}


                                       //NORMAL SAVE METHOD WITH RESPONSE
//@PostMapping(value="/saveEmployee" , produces ="application/json")
//public ResponseEntity<Object> saveEmployeeControler(@RequestBody Employee employee){
//	System.out.println("employeesaved"+employee);
//          Employee employee2=employeedao.saveEmployeeDao(employee);
//          
//          if(employee2 != null) {
//        	  return ResponseEntity.ok().body("Employee saved Successfully with id :"+employee2.getId());
//          }else {
//			return ResponseEntity.ok("Sometging went wromg");
//		}
//}

//=====================================SAVE METHOD WITH RESPONSE & VALIDATION WITH EXCEPTION HANDLED===================

@PostMapping(value="/saveEmployee")
@Operation(summary = "SAVE-EMPLOYEE", description = "API to save employee data")      //employeeRequest is in JSON FORM given by user
public ResponseEntity<Object> saveEmployeeControler(@RequestBody @Valid EmployeeRequest employeeRequest){
	   Employee employee= EmployeeMapper.convertToEmployee(employeeRequest);
	   
	   System.out.println("Employee saved"+ employee);
          Employee employee2=employeedao.saveEmployeeDao(employee);
          
          if(employee2 != null) {
        	  return ResponseEntity.ok().body("Employee saved Successfully with id :"+employee2.getId());
          }else {
			return ResponseEntity.ok("Sometging went wromg");
		}
}


//======================================// NORMAL GETeMPLOYEE BY ID CONTROLLER====================================

//@GetMapping(value="/getEmployeeById/{id}")
//public Employee getEmployeeById(@PathVariable (name="id") int id) {
//	return employeedao.getEmployeeByIdDao(id);
//	
//}

@GetMapping(value="/getEmployeeById/{id}")
public ResponseEntity<Map<String,Object>> getEmployeeById(@PathVariable (name="id") int id) {
	   Map<String,Object> map=new HashMap<String,Object>();
	   
	   Employee employee =employeedao.getEmployeeByIdDao(id);
	     if(employee != null) {
	    	 map.put("employee-data = ", employee);
	    	 return new ResponseEntity<Map<String,Object>>(map, HttpStatus.FOUND);
	     } else {
	    	 map.put("message = ", "given id employee not found");
	    	 return new ResponseEntity<Map<String,Object>>(map, HttpStatus.NOT_FOUND);
		}
	   
}
//==================================================================================================================== 


@GetMapping(value="/getAllEmployee")
public List<Employee> getAllEmployeeController(){
	return employeedao.getAllEmployeeDao();
}

@PostMapping(value="/saveMultipleEmployee")
public List<Employee> saveMultipleEmployeeontroller(@RequestBody List<Employee> employees){
	return employeedao.saveMultipleEmployeeDao(employees);
}

@GetMapping(value="/getEmployeeByEmail/{email}")         // here exception is used
public Employee getEmployeeByEmailController(@PathVariable (name="email") String email) {
	Employee employee = employeedao.getEmployeeByemailDao(email);
	
	if(employee==null) {
		throw new EmployeeNotFoundException("Employee with email "+email+"is not found");
	}
	return employee;
}

@GetMapping(value="/getEmployeeByName/{name}")
public List<Employee> getEmployeeByNameController(@PathVariable(name="name") String name){
	return employeedao.getEmployeeByNameDao(name);
	
}

@DeleteMapping(value="/deleteEmployeeByName/{name}")
public Boolean deleteEmployeeByNameController(@PathVariable(name="name") String name) {
	return employeedao.deleteEmployeeByNameDao(name);
	
}

@GetMapping(value="/getEmployeeWithPageNumber/{pagenumber}")
public Page<Employee> getEmployeeWithPageNumber(@PathVariable (name="pagenumber") int pagenumber){
	     return employeedao.getEmployeeWithPageNUmberDao(pagenumber);
		      
}

@GetMapping(value="sortEmployeeBySalaryController")
public List<Employee>sortEmployeeBySalaryController (String salary){
	return employeedao.SortEmployeeBysalaryDao(salary);
}
  
@GetMapping(value="sortEmployeeByAttributeNameController")    // without pathvariable it is working
public List<Employee> sortEmployeeByAttributeNameController(String attributeName){
	return employeedao.sortEmployeeByAttributeNameDao(attributeName);
	
}

@GetMapping(value="sortEmployeeByAttributeNameByDescController/{attributeName}")
public List<Employee> sortEmployeeByAttributeNameByDescController(@PathVariable(name="attributeName") String attributeName){
	return employeedao.sortEmployeeByAttributeNameDao(attributeName);
			   
}



}
