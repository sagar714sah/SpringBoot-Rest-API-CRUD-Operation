package com.technoelevate.spring_boot_rest_api_crud_with_mysql.exception;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApplicationExceptionHandler {

	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<String> handleEmployeeNotFoundException(EmployeeNotFoundException exception){
		
		return ResponseEntity.badRequest().body(exception.getMessage());
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> methodArgumentNotValidException(MethodArgumentNotValidException ex) {
	Map<String, String> map= new HashMap<String,String>();
	
	BindingResult bindingResult=ex.getBindingResult();
	
	List<ObjectError> errors= bindingResult.getAllErrors();
	
	  for (ObjectError objectError : errors){
		  FieldError fieldError = (FieldError) objectError;
		  
		  String fieldName = fieldError.getField();
		  String message = fieldError.getDefaultMessage();
		  
		  map.put(fieldName, message);
		
	}
	  return ResponseEntity.badRequest().body(map);
}

}
