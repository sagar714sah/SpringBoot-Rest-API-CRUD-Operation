package com.technoelevate.spring_boot_rest_api_crud_with_mysql.Dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRequest {

	

	

		
		private int id;
		
		@NotEmpty(message="Name must not be empty")
		private String name;
		
		@NotEmpty(message="Name must not be empty")
		@Email(message="Email should be valid")
		private String email;
		
		@NotEmpty(message="Department must not be empty")
		private String department;
		
		@Min(value=2100, message="salary must be at least 2100")
		@Max(value=50000, message="salary must not exceed 50000")
		private double salary;
		
		@PastOrPresent(message="joining date must be in the past or present")
		private LocalDate joiningdate;
	
}
